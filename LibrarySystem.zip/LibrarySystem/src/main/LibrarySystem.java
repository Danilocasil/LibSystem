package main;

import java.util.Scanner;
import java.util.Stack;

public class LibrarySystem {
    private Stack<String> availableBooks;
    private Stack<String> borrowedBooks;

    public LibrarySystem() {
        availableBooks = new Stack<>();
        borrowedBooks = new Stack<>();
        initializeAvailableBooks();
    }

    private void initializeAvailableBooks() {
        availableBooks.push("The Mountain is You | Brianna Wiest");
        availableBooks.push("101 Essays that will change the way you think | Brianna Wiest");
        availableBooks.push("Don't Fucking Panic | Kelsey Darragh");
        availableBooks.push("Daring to take up space | Daniell Koepke");
        availableBooks.push("Mein Kampf | Adolph Hitler");
    }

    public void displayAvailableBooks() {
        System.out.println("Display available books:");
        int bookNumber = 1;
        for (String book : availableBooks) {
            System.out.println("[" + bookNumber + "] " + book);
            bookNumber++;
        }
    }

    public void addBook(String title, String author) {
        String book = title + " | " + author;
        availableBooks.push(book);
        System.out.println("Added book: " + book);
    }

    public void borrowBook(int bookNumber) {
        if (bookNumber >= 1 && bookNumber <= availableBooks.size()) {
            String book = availableBooks.remove(bookNumber - 1);
            borrowedBooks.push(book);
            System.out.println("Borrowed: " + book);
        } else {
            System.out.println("Invalid book number.");
        }
    }

    public void returnBook() {
        if (!borrowedBooks.isEmpty()) {
            String returnedBook = borrowedBooks.pop();
            availableBooks.push(returnedBook);
            System.out.println("Returned: " + returnedBook);
        } else {
            System.out.println("You have no borrowed books to return.");
        }
    }

    public void displayBorrowedBooks() {
        System.out.println("Your borrowed books:");
        for (String book : borrowedBooks) {
            System.out.println(book);
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        LibrarySystem library = new LibrarySystem();

        while (true) {
            System.out.println("Library Menu:");
            System.out.println("1. Add a book to the library");
            System.out.println("2. Display available books");
            System.out.println("3. Borrow a book");
            System.out.println("4. Return a book");
            System.out.println("5. Display borrowed books");
            System.out.println("6. Exit");

            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character

            switch (choice) {
                case 1:
                    System.out.print("Enter the book title: ");
                    String title = scanner.nextLine();
                    System.out.print("Enter the author: ");
                    String author = scanner.nextLine();
                    library.addBook(title, author);
                    break;
                case 2:
                    library.displayAvailableBooks();
                    break;
                case 3:
                    System.out.print("Enter the book number you want to borrow: ");
                    int bookNumber = scanner.nextInt();
                    scanner.nextLine(); // Consume the newline character
                    library.borrowBook(bookNumber);
                    break;
                case 4:
                    library.returnBook();
                    break;
                case 5:
                    library.displayBorrowedBooks();
                    break;
                case 6:
                    System.out.println("Goodbye!");
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please choose a valid option.");
            }
        }
    }
}
